# Provincias
provincias  de España con google maps


Ejemplos de instalación
--------------------

Los siguientes pasos son para realizar la instalacion del sistema de provincias:
+ Instalar la base de datos Mysql db.sql
+ Ingresar a : /php/modeloAbstractoDB.php y modificar la conexion de la base de datos $db_host, $db_user, $db_pass, $db_name
+ Ejecutar sistema en el navegador
